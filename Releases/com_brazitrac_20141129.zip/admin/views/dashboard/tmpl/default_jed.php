<?php
/**
 * @package		$Id: default_jed.php 2 2014-07-30 08:16:00Z RS $
 * @author 		Robert Skolnick
 * @copyright	2007-2014 BraziTech. All rights reserved.
 * @license		GNU/GPL.
 */
// no direct access
defined('_JEXEC') or die;
?>
 <div class="brazitrac-jed">
 	<?php echo sprintf(JText::_('COM_BRAZITRAC_CPANEL_JED'), 'http://brazitrac.com'); ?>
 </div>
